import XCTest

import artOfWarTests

var tests = [XCTestCaseEntry]()
tests += artOfWarTests.allTests()
XCTMain(tests)
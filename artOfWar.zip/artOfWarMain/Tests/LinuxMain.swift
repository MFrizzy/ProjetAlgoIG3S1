import XCTest

import artOfWarMainTests

var tests = [XCTestCaseEntry]()
tests += artOfWarMainTests.allTests()
XCTMain(tests)